package com.cngride.cng_ride_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

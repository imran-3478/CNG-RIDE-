import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/geocode_service.dart';
import '../services/location_service.dart';

/// Passenger live tracking: driver marker, route line, ETA, driver card.
class TrackingScreen extends StatefulWidget {
  final String rideId;
  const TrackingScreen({super.key, required this.rideId});

  @override
  State<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends State<TrackingScreen> {
  final _mapCtrl = MapController();
  Map<String, dynamic>? _ride;
  Map<String, dynamic>? _driver;
  Position? _myPos;
  LatLng? _driverPos;
  LatLng? _destPos;
  String? _status;
  String? _error;
  bool _cancelling = false;

  RealtimeChannel? _channel;
  Timer? _pollTimer;
  StreamSubscription<Position>? _posSub;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _loadRide();
    if (!mounted || _ride == null) return;

    // Destination coordinates (best effort geocode of the address text).
    final destAddr = (_ride!['destination_address'] ?? '').toString();
    if (destAddr.isNotEmpty) {
      final places = await GeocodeService.search(destAddr);
      if (mounted && places.isNotEmpty) {
        setState(
            () => _destPos = LatLng(places.first.lat, places.first.lng));
      }
    }

    final pos = await LocationService.currentPosition();
    if (mounted) {
      setState(() => _myPos = pos);
      if (pos != null) {
        _mapCtrl.move(LatLng(pos.latitude, pos.longitude), 14);
      }
    }
    _posSub = LocationService.positionStream().listen((p) {
      if (mounted) setState(() => _myPos = p);
    });

    _pollDriver();
    _pollTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _pollDriver());

    // Realtime ride-status changes.
    _channel = Supabase.instance.client.channel('track-${widget.rideId}');
    _channel!.onPostgresChanges(
      event: PostgresChangeEvent.update,
      schema: 'public',
      table: 'ride_requests',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'id',
        value: widget.rideId,
      ),
      callback: (payload) {
        final rec = payload.newRecord;
        final st = rec['status']?.toString();
        if (st == null || !mounted) return;
        setState(() => _status = st);
        if (st == 'completed') {
          _finish('রাইড সম্পন্ন হয়েছে। ধন্যবাদ!');
        } else if (st == 'rejected' || st == 'cancelled') {
          _finish('রাইডটি বাতিল হয়েছে।');
        }
      },
    );
    _channel!.subscribe();
  }

  Future<void> _loadRide() async {
    try {
      final ride = await Supabase.instance.client
          .from('ride_requests')
          .select()
          .eq('id', widget.rideId)
          .maybeSingle();
      if (!mounted) return;
      if (ride == null) {
        setState(() => _error = 'রাইড পাওয়া যায়নি');
        return;
      }
      setState(() {
        _ride = ride;
        _status = ride['status']?.toString();
      });
      final driverId = ride['driver_id']?.toString();
      if (driverId != null) {
        final drv = await Supabase.instance.client
            .from('drivers')
            .select(
                'vehicle_name, vehicle_number, latitude, longitude, profiles(full_name, phone)')
            .eq('id', driverId)
            .maybeSingle();
        if (!mounted) return;
        setState(() => _driver = drv);
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'লোড করতে সমস্যা হয়েছে');
    }
  }

  Future<void> _pollDriver() async {
    try {
      final driverId = _ride?['driver_id']?.toString();
      if (driverId == null) return;
      final drv = await Supabase.instance.client
          .from('drivers')
          .select('latitude,longitude')
          .eq('id', driverId)
          .maybeSingle();
      if (!mounted || drv == null) return;
      final lat = (drv['latitude'] as num?)?.toDouble();
      final lng = (drv['longitude'] as num?)?.toDouble();
      if (lat != null && lng != null && lat != 0) {
        setState(() => _driverPos = LatLng(lat, lng));
      }
    } catch (_) {}
  }

  void _finish(String msg) {
    _pollTimer?.cancel();
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
    Navigator.pop(context);
  }

  Future<void> _cancelRide() async {
    setState(() => _cancelling = true);
    try {
      await Supabase.instance.client
          .from('ride_requests')
          .update({'status': 'cancelled'}).eq('id', widget.rideId);
      if (mounted) _finish('রাইড বাতিল করা হয়েছে');
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'বাতিল করা যায়নি');
        setState(() => _cancelling = false);
      }
    }
  }

  Future<void> _callDriver() async {
    final prof = _driver?['profiles'] as Map<String, dynamic>?;
    final phone = (prof?['phone'] ?? '').toString();
    if (phone.isEmpty) return;
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  String get _statusText {
    switch (_status) {
      case 'pending':
        return 'ড্রাইভারের উত্তরের অপেক্ষায়…';
      case 'accepted':
        return 'ড্রাইভার আসছে…';
      default:
        return _status ?? '';
    }
  }

  String get _etaText {
    if (_driverPos == null || _destPos == null) return '';
    final km = LocationService.distanceKm(_driverPos!.latitude,
        _driverPos!.longitude, _destPos!.latitude, _destPos!.longitude);
    final mins = (km / 25 * 60).round(); // ~25 km/h city speed
    return 'ETA ~$mins মিনিট (${km.toStringAsFixed(1)} কিমি)';
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _posSub?.cancel();
    if (_channel != null) {
      Supabase.instance.client.removeChannel(_channel!);
    }
    _mapCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('লাইভ ট্র্যাকিং')),
        body: Center(child: Text(_error!)),
      );
    }
    if (_ride == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final markers = <Marker>[
      if (_driverPos != null)
        Marker(
          point: _driverPos!,
          width: 44,
          height: 44,
          child: const Icon(Icons.local_taxi,
              color: Colors.green, size: 40),
        ),
      if (_myPos != null)
        Marker(
          point: LatLng(_myPos!.latitude, _myPos!.longitude),
          width: 24,
          height: 24,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
          ),
        ),
      if (_destPos != null)
        Marker(
          point: _destPos!,
          width: 44,
          height: 44,
          child:
              const Icon(Icons.location_pin, color: Colors.red, size: 44),
        ),
    ];

    final polylines = <Polyline>[
      if (_driverPos != null && _destPos != null)
        Polyline(
          points: [_driverPos!, _destPos!],
          color: Colors.green,
          strokeWidth: 4,
        ),
    ];

    final prof = _driver?['profiles'] as Map<String, dynamic>?;
    final driverName =
        (prof?['full_name'] ?? _driver?['vehicle_name'] ?? 'ড্রাইভার')
            .toString();
    final vehicleNo = (_driver?['vehicle_number'] ?? '').toString();
    final fare = (_ride!['estimated_fare'] as num?)?.toStringAsFixed(0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('লাইভ ট্র্যাকিং'),
        automaticallyImplyLeading: false,
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapCtrl,
            options: const MapOptions(
              initialCenter:
                  LatLng(AppConfig.tangailLat, AppConfig.tangailLng),
              initialZoom: 13,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.cngride.cng_ride_app',
              ),
              PolylineLayer(polylines: polylines),
              MarkerLayer(markers: markers),
            ],
          ),
          Positioned(
            top: 12,
            left: 12,
            right: 12,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_statusText,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    if (_etaText.isNotEmpty)
                      Text(_etaText,
                          style:
                              const TextStyle(color: Colors.grey)),
                    if (fare != null) Text('ভাড়া: ৳$fare'),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 24,
                      child: Icon(Icons.person),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(driverName,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16)),
                          if (vehicleNo.isNotEmpty)
                            Text(vehicleNo,
                                style: const TextStyle(
                                    color: Colors.grey)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.call,
                          color: Colors.green, size: 30),
                      onPressed: _callDriver,
                    ),
                    const SizedBox(width: 4),
                    ElevatedButton(
                      onPressed:
                          _cancelling ? null : _cancelRide,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade50,
                        foregroundColor: Colors.red,
                      ),
                      child: _cancelling
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2))
                          : const Text('বাতিল'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

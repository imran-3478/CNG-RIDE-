import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/geocode_service.dart';
import '../services/location_service.dart';
import '../widgets/app_drawer.dart';
import '../widgets/map_widgets.dart';
import 'login_screen.dart';
import 'tracking_screen.dart';

/// Passenger home: map with nearby available drivers, destination search,
/// fare estimate and ride booking (mirrors web v5.2).
class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});

  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final _mapCtrl = MapController();
  final _searchCtrl = TextEditingController();

  Position? _myPos;
  List<Map<String, dynamic>> _drivers = [];
  List<PlaceResult> _searchResults = [];
  bool _searching = false;

  PlaceResult? _dest;
  double? _destKm;
  double? _destFare;
  String? _selectedDriverId;
  bool _booking = false;
  String? _error;
  bool _isSatellite = false;

  StreamSubscription<Position>? _posSub;
  Timer? _driverTimer;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final pos = await LocationService.currentPosition();
    if (!mounted) return;
    setState(() => _myPos = pos);
    if (pos != null) {
      _mapCtrl.move(LatLng(pos.latitude, pos.longitude), 15);
    }
    await _loadDrivers();
    await _checkActiveRide();
    _posSub = LocationService.positionStream().listen((p) {
      if (mounted) setState(() => _myPos = p);
    });
    _driverTimer = Timer.periodic(const Duration(seconds: 20), (_) {
      _loadDrivers();
    });
  }

  Future<void> _loadDrivers() async {
    try {
      final rows = await Supabase.instance.client
          .from('drivers')
          .select(
              'id, vehicle_name, vehicle_number, latitude, longitude, profiles(full_name, phone)')
          .eq('available', true);
      if (!mounted) return;
      setState(() {
        _drivers = (rows as List)
            .where((d) =>
                d['latitude'] != null &&
                d['longitude'] != null &&
                (d['latitude'] as num) != 0)
            .cast<Map<String, dynamic>>()
            .toList();
        if (_selectedDriverId != null &&
            !_drivers.any((d) => d['id'] == _selectedDriverId)) {
          _selectedDriverId = null;
        }
        _selectedDriverId ??=
            _drivers.isNotEmpty ? _drivers.first['id'] as String : null;
      });
    } catch (_) {
      // Keep old list on transient errors.
    }
  }

  /// If the passenger already has a live ride, jump straight to tracking.
  Future<void> _checkActiveRide() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      final ride = await Supabase.instance.client
          .from('ride_requests')
          .select('id')
          .eq('passenger_id', uid)
          .inFilter('status', ['pending', 'accepted']).maybeSingle();
      if (!mounted) return;
      if (ride != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => TrackingScreen(rideId: ride['id'] as String),
          ),
        );
      }
    } catch (_) {}
  }

  Future<void> _search() async {
    final q = _searchCtrl.text.trim();
    if (q.length < 3) return;
    setState(() {
      _searching = true;
      _searchResults = [];
    });
    final results = await GeocodeService.search(q);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _searchResults = results;
      if (results.isEmpty) _error = 'গন্তব্য পাওয়া যায়নি';
    });
  }

  void _pickPlace(PlaceResult p) {
    double? km;
    double? fare;
    if (_myPos != null) {
      km = LocationService.distanceKm(
          _myPos!.latitude, _myPos!.longitude, p.lat, p.lng);
      fare = AppConfig.estimateFare(km);
    }
    setState(() {
      _dest = p;
      _destKm = km;
      _destFare = fare;
      _searchResults = [];
      _error = null;
    });
    _mapCtrl.move(LatLng(p.lat, p.lng), 14);
  }

  String _driverLabel(Map<String, dynamic> d) {
    final prof = d['profiles'] as Map<String, dynamic>?;
    final name = (prof?['full_name'] ?? d['vehicle_name'] ?? 'ড্রাইভার').toString();
    final num = (d['vehicle_number'] ?? '').toString();
    return num.isEmpty ? name : '$name ($num)';
  }

  /// Open the picked destination in the Google Maps app.
  Future<void> _openInGoogleMaps() async {
    if (_dest == null) return;
    final uri = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${_dest!.lat},${_dest!.lng}');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  Future<void> _book() async {
    if (_dest == null || _myPos == null || _selectedDriverId == null) return;
    setState(() {
      _booking = true;
      _error = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      final inserted = await Supabase.instance.client
          .from('ride_requests')
          .insert({
            'passenger_id': uid,
            'driver_id': _selectedDriverId,
            'pickup_lat': _myPos!.latitude,
            'pickup_lng': _myPos!.longitude,
            'pickup_address': 'Current Live Location',
            'destination_address': _dest!.name,
            'status': 'pending',
            'fare_per_km': AppConfig.farePerKm,
            'distance_km': _destKm,
            'estimated_fare': _destFare,
          })
          .select('id')
          .single();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              TrackingScreen(rideId: inserted['id'] as String),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'বুকিং ব্যর্থ: আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _booking = false);
    }
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _driverTimer?.cancel();
    _searchCtrl.dispose();
    _mapCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final center = _myPos != null
        ? LatLng(_myPos!.latitude, _myPos!.longitude)
        : const LatLng(AppConfig.tangailLat, AppConfig.tangailLng);

    final markers = <Marker>[
      if (_myPos != null)
        Marker(
          point: LatLng(_myPos!.latitude, _myPos!.longitude),
          width: 24,
          height: 24,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
          ),
        ),
      for (final d in _drivers)
        Marker(
          point: LatLng((d['latitude'] as num).toDouble(),
              (d['longitude'] as num).toDouble()),
          width: 44,
          height: 44,
          child: GestureDetector(
            onTap: () =>
                setState(() => _selectedDriverId = d['id'] as String),
            child: Icon(
              Icons.local_taxi,
              color: d['id'] == _selectedDriverId
                  ? Colors.orange
                  : Colors.green,
              size: 40,
            ),
          ),
        ),
      if (_dest != null)
        Marker(
          point: LatLng(_dest!.lat, _dest!.lng),
          width: 44,
          height: 44,
          child: const Icon(Icons.location_pin,
              color: Colors.red, size: 44),
        ),
    ];

    return Scaffold(
      drawer: const AppDrawer(isDriver: false),
      appBar: AppBar(
        title: const Text('CNG Ride'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadDrivers,
            tooltip: 'ড্রাইভার রিফ্রেশ',
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapCtrl,
            options: MapOptions(
              initialCenter: center,
              initialZoom: 14,
            ),
            children: [
              buildTileLayer(_isSatellite),
              MarkerLayer(markers: markers),
            ],
          ),
          SatelliteToggle(
            isSatellite: _isSatellite,
            onToggle: () =>
                setState(() => _isSatellite = !_isSatellite),
          ),
          // Destination search bar
          Positioned(
            top: 12,
            left: 12,
            right: 12,
            child: Column(
              children: [
                Material(
                  elevation: 4,
                  borderRadius: BorderRadius.circular(12),
                  child: TextField(
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: InputDecoration(
                      hintText: 'গন্তব্য লিখুন (যেমন: করটিয়া)',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searching
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2)),
                            )
                          : IconButton(
                              icon: const Icon(Icons.arrow_forward),
                              onPressed: _search,
                            ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),
                if (_searchResults.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(blurRadius: 8, color: Colors.black26)
                      ],
                    ),
                    constraints: const BoxConstraints(maxHeight: 220),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: _searchResults.length,
                      itemBuilder: (_, i) {
                        final p = _searchResults[i];
                        return ListTile(
                          dense: true,
                          leading: const Icon(Icons.location_on,
                              color: Colors.red),
                          title: Text(
                            p.name.length > 70
                                ? '${p.name.substring(0, 70)}…'
                                : p.name,
                            style: const TextStyle(fontSize: 13),
                          ),
                          onTap: () => _pickPlace(p),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
          if (_error != null)
            Positioned(
              top: 76,
              left: 12,
              right: 12,
              child: Material(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.red)),
                ),
              ),
            ),
          // Booking card
          if (_dest != null)
            Positioned(
              left: 12,
              right: 12,
              bottom: 12,
              child: Card(
                elevation: 6,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.location_pin,
                              color: Colors.red),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _dest!.name.length > 60
                                  ? '${_dest!.name.substring(0, 60)}…'
                                  : _dest!.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => setState(() {
                              _dest = null;
                              _destKm = null;
                              _destFare = null;
                            }),
                          ),
                        ],
                      ),
                      if (_destKm != null && _destFare != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          'দূরত্ব: ${_destKm!.toStringAsFixed(1)} কিমি   •   আনুমানিক ভাড়া: ৳${_destFare!.toStringAsFixed(0)}',
                          style: const TextStyle(fontSize: 15),
                        ),
                      ] else
                        const Text(
                          'লোকেশন পাওয়া যায়নি — দূরত্ব হিসাব করা যাচ্ছে না',
                          style:
                              TextStyle(color: Colors.orange, fontSize: 13),
                        ),
                      const SizedBox(height: 8),
                      if (_drivers.isEmpty)
                        const Text(
                          'এখন কোনো ড্রাইভার available নেই',
                          style: TextStyle(color: Colors.red),
                        )
                      else
                        SizedBox(
                          height: 40,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              for (final d in _drivers)
                                Padding(
                                  padding:
                                      const EdgeInsets.only(right: 8),
                                  child: ChoiceChip(
                                    label: Text(_driverLabel(d)),
                                    selected:
                                        d['id'] == _selectedDriverId,
                                    onSelected: (_) => setState(() =>
                                        _selectedDriverId =
                                            d['id'] as String),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: (_booking ||
                                _drivers.isEmpty ||
                                _myPos == null)
                            ? null
                            : _book,
                        style: ElevatedButton.styleFrom(
                          padding:
                              const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: _booking
                            ? const CircularProgressIndicator(
                                color: Colors.white)
                            : const Text('রাইড বুক করো',
                                style: TextStyle(fontSize: 18)),
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _openInGoogleMaps,
                        icon: const Icon(Icons.map),
                        label:
                            const Text('Google Maps-এ দেখো'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'login_screen.dart';

/// User profile: view name/phone/user-type, edit name, logout.
/// Matches the web app's profile modal.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String? _success;
  String _name = '';
  String _phone = '';
  String _userType = '';
  final _nameCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      final row = await Supabase.instance.client
          .from('profiles')
          .select('full_name, phone, user_type')
          .eq('id', uid)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _name = (row?['full_name'] ?? '').toString();
        _phone = (row?['phone'] ?? '').toString();
        _userType = (row?['user_type'] ?? '').toString();
        _nameCtrl.text = _name;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'প্রোফাইল লোড হয়নি';
        _loading = false;
      });
    }
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'নাম লিখুন');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
      _success = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      await Supabase.instance.client
          .from('profiles')
          .update({'full_name': name}).eq('id', uid);
      if (!mounted) return;
      setState(() {
        _name = name;
        _success = 'প্রোফাইল আপডেট হয়েছে ✅';
        _saving = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'সেভ করা যায়নি';
        _saving = false;
      });
    }
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('প্রোফাইল')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.account_circle,
                      size: 90, color: Colors.teal),
                  const SizedBox(height: 12),
                  Center(
                    child: Text(
                      _name.isEmpty ? '—' : _name,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Center(
                    child: Text(
                      _userType == 'driver' ? 'ড্রাইভার' : 'যাত্রী',
                      style:
                          const TextStyle(color: Colors.grey, fontSize: 15),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Card(
                    child: ListTile(
                      leading:
                          const Icon(Icons.phone, color: Colors.teal),
                      title: const Text('মোবাইল নম্বর'),
                      subtitle: Text(
                          _phone.isEmpty ? '—' : _phone,
                          style: const TextStyle(fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('নাম পরিবর্তন',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _nameCtrl,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'আপনার নাম',
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _saving ? null : _save,
                    style: ElevatedButton.styleFrom(
                        padding:
                            const EdgeInsets.symmetric(vertical: 14)),
                    child: _saving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : const Text('সেভ করো',
                            style: TextStyle(fontSize: 17)),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center),
                  ],
                  if (_success != null) ...[
                    const SizedBox(height: 12),
                    Text(_success!,
                        style: const TextStyle(color: Colors.green),
                        textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 32),
                  OutlinedButton.icon(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout, color: Colors.red),
                    label: const Text('লগআউট',
                        style: TextStyle(color: Colors.red)),
                    style: OutlinedButton.styleFrom(
                        padding:
                            const EdgeInsets.symmetric(vertical: 14)),
                  ),
                ],
              ),
            ),
    );
  }
}

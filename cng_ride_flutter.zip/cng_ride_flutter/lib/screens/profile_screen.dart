import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../widgets/app_theme.dart';
import 'login_screen.dart';
import 'ride_history_screen.dart';
import 'support_screens.dart';
import 'wallet_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _loading = true;
  bool _uploading = false;
  String _name = '';
  String _phone = '';
  String _userType = '';
  String? _avatarUrl;
  final _nameCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      final row = await Supabase.instance.client
          .from('profiles')
          .select('full_name, phone, user_type, avatar_url')
          .eq('id', uid)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _name = (row?['full_name'] ?? '').toString();
        _phone = (row?['phone'] ?? '').toString();
        _userType = (row?['user_type'] ?? '').toString();
        final av = row?['avatar_url'];
        _avatarUrl = av == null ? null : av.toString();
        _nameCtrl.text = _name;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickAndUpload() async {
    try {
      final img = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
      );
      if (img == null) return;
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      setState(() => _uploading = true);
      final bytes = await img.readAsBytes();
      final path = '$uid/avatar.jpg';
      await Supabase.instance.client.storage.from('avatars').uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(upsert: true),
          );
      final url = Supabase.instance.client.storage
          .from('avatars')
          .getPublicUrl(path);
      await Supabase.instance.client
          .from('profiles')
          .update({'avatar_url': url}).eq('id', uid);
      if (!mounted) return;
      setState(() {
        _avatarUrl = url;
        _uploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ছবি আপলোড হয়েছে')),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() => _uploading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('আপলোড ব্যর্থ হয়েছে')),
      );
    }
  }

  Future<void> _saveName() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) return;
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      await Supabase.instance.client
          .from('profiles')
          .update({'full_name': name}).eq('id', uid);
      if (!mounted) return;
      setState(() => _name = name);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('নাম আপডেট হয়েছে')),
      );
    } catch (_) {}
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  void _editName() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('প্রোফাইল সম্পাদনা'),
        content: TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
            labelText: 'আপনার নাম',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('বাতিল'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _saveName();
            },
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDriver = _userType == 'driver';
    final hasAvatar = _avatarUrl != null && _avatarUrl!.isNotEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('প্রোফাইল')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: const BoxDecoration(
                      gradient: AppTheme.gradient,
                    ),
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: _uploading ? null : _pickAndUpload,
                          child: Stack(
                            children: [
                              CircleAvatar(
                                radius: 40,
                                backgroundColor:
                                    Colors.white.withOpacity(0.2),
                                backgroundImage: hasAvatar
                                    ? NetworkImage(_avatarUrl!)
                                    : null,
                                child: hasAvatar
                                    ? null
                                    : const Icon(
                                        Icons.person,
                                        size: 48,
                                        color: Colors.white,
                                      ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: const BoxDecoration(
                                    color: AppTheme.amber,
                                    shape: BoxShape.circle,
                                  ),
                                  child: _uploading
                                      ? const SizedBox(
                                          width: 14,
                                          height: 14,
                                          child:
                                              CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : const Icon(
                                          Icons.camera_alt,
                                          size: 14,
                                          color: Colors.black87,
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _name.isEmpty ? '—' : _name,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          _phone,
                          style:
                              const TextStyle(color: Colors.white70),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            isDriver ? 'ড্রাইভার' : 'যাত্রী',
                            style: const TextStyle(
                                color: Colors.white, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _menu(Icons.person_outline, 'আমার তথ্য', _editName),
                  if (isDriver)
                    _menu(
                      Icons.account_balance_wallet_outlined,
                      'ওয়ালেট ও রিচার্জ',
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const WalletScreen()),
                      ),
                    ),
                  _menu(
                    Icons.history_outlined,
                    'রাইড হিস্ট্রি',
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) =>
                              const RideHistoryScreen()),
                    ),
                  ),
                  _menu(Icons.shield_outlined, 'সেফটি ও প্রাইভেসি',
                      () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const SafetyPrivacyScreen()),
                          )),
                  _menu(Icons.help_outline, 'সাহায্য ও সাপোর্ট',
                      () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const SupportScreen()),
                          )),
                  _menu(Icons.settings_outlined, 'অ্যাপ সেটিংস',
                      () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const SettingsScreen()),
                          )),
                  const SizedBox(height: 8),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    child: SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: _logout,
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(
                              vertical: 14),
                        ),
                        child: const Text(
                          'লগআউট',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
    );
  }

  Widget _menu(IconData icon, String title, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppTheme.green50,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: AppTheme.green800, size: 22),
        ),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.w500)),
        trailing:
            const Icon(Icons.chevron_right, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Admin panel: total commission, pending recharge requests,
/// approve/reject. Only for admin emails (see AppConfig).
/// Matches the web app's admin panel.
class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  bool _loading = true;
  String? _error;
  double _totalCommission = 0;
  List<Map<String, dynamic>> _pending = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      double commission = 0;
      try {
        final c = await Supabase.instance.client
            .rpc('admin_total_commission');
        commission = (c as num?)?.toDouble() ?? 0;
      } catch (_) {}
      final data = await Supabase.instance.client
          .from('recharge_requests')
          .select(
              'id, amount, trx_id, sender_number, status, created_at, driver_id')
          .eq('status', 'pending')
          .order('created_at', ascending: false);
      if (!mounted) return;
      setState(() {
        _totalCommission = commission;
        _pending =
            List<Map<String, dynamic>>.from(data as List);
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'লোড হয়নি';
        _loading = false;
      });
    }
  }

  Future<void> _approve(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Approve করবেন?'),
        content: const Text('এই রিচার্জ approve করবেন?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('না'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('হ্যাঁ'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Supabase.instance.client.rpc('admin_approve_recharge',
          params: {'p_request_id': id});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Approve হয়েছে')));
      _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ব্যর্থ: $e')));
    }
  }

  Future<void> _reject(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reject করবেন?'),
        content: const Text('এই রিকোয়েস্ট reject করবেন?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('না'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('হ্যাঁ, Reject'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Supabase.instance.client
          .from('recharge_requests')
          .update({'status': 'rejected'}).eq('id', id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Reject করা হয়েছে')));
      _load();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ব্যর্থ হয়েছে')));
    }
  }

  String _dateBn(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final d = DateTime.parse(iso).toLocal();
      return '${d.day}/${d.month}/${d.year} ${d.hour}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('👑 Admin Panel')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: SingleChildScrollView(
                    physics:
                        const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Card(
                                color: Colors.purple.shade50,
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    children: [
                                      const Text('মোট কমিশন',
                                          style: TextStyle(
                                              color: Colors.grey)),
                                      Text(
                                        '৳${_totalCommission.toStringAsFixed(0)}',
                                        style: const TextStyle(
                                            fontSize: 24,
                                            fontWeight:
                                                FontWeight.bold,
                                            color: Colors.purple),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Card(
                                color: Colors.orange.shade50,
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    children: [
                                      const Text(
                                          'পেন্ডিং রিচার্জ',
                                          style: TextStyle(
                                              color: Colors.grey)),
                                      Text(
                                        '${_pending.length}',
                                        style: const TextStyle(
                                            fontSize: 24,
                                            fontWeight:
                                                FontWeight.bold,
                                            color: Colors.orange),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        const Text('পেন্ডিং রিচার্জ রিকোয়েস্ট',
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        if (_pending.isEmpty)
                          const Card(
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Center(
                                  child: Text(
                                      'কোনো পেন্ডিং রিকোয়েস্ট নেই ✅')),
                            ),
                          )
                        else
                          ..._pending.map((r) => Card(
                                margin: const EdgeInsets.only(
                                    bottom: 10),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment
                                                .spaceBetween,
                                        children: [
                                          Text(
                                            '৳${(r['amount'] as num?)?.toStringAsFixed(0) ?? '—'}',
                                            style: const TextStyle(
                                                fontSize: 20,
                                                fontWeight:
                                                    FontWeight.bold),
                                          ),
                                          Text(
                                            _dateBn(r['created_at']
                                                ?.toString()),
                                            style: const TextStyle(
                                                color: Colors.grey,
                                                fontSize: 12),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                          'TrxID: ${r['trx_id'] ?? '—'}'),
                                      if (r['sender_number'] !=
                                          null)
                                        Text(
                                          'পাঠিয়েছে: ${r['sender_number']}',
                                          style: const TextStyle(
                                              fontWeight:
                                                  FontWeight.w500),
                                        ),
                                      Text(
                                        'Driver: ${(r['driver_id'] ?? '').toString().substring(0, 8)}…',
                                        style: const TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12),
                                      ),
                                      const SizedBox(height: 10),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: ElevatedButton(
                                              onPressed: () =>
                                                  _approve(r['id']
                                                      .toString()),
                                              style: ElevatedButton
                                                  .styleFrom(
                                                backgroundColor:
                                                    Colors.green,
                                                foregroundColor:
                                                    Colors.white,
                                              ),
                                              child: const Text(
                                                  'Approve'),
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: OutlinedButton(
                                              onPressed: () =>
                                                  _reject(r['id']
                                                      .toString()),
                                              style: OutlinedButton
                                                  .styleFrom(
                                                foregroundColor:
                                                    Colors.red,
                                              ),
                                              child: const Text(
                                                  'Reject'),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              )),
                      ],
                    ),
                  ),
                ),
    );
  }
}

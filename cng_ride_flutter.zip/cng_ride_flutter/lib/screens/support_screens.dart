import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../widgets/app_theme.dart';

/// Support numbers (single place to change).
class SupportConfig {
  /// Number users call for help.
  static const supportPhone = '01935535265';

  /// bKash/Nagad number drivers send recharge money to.
  static const paymentNumber = '01767462347';
}

/// Support screen: shows the helpline number with call button.
class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  Future<void> _call(BuildContext context) async {
    final uri = Uri.parse('tel:${SupportConfig.supportPhone}');
    try {
      await launchUrl(uri);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('কল করা যায়নি')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সাহায্য ও সাপোর্ট')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.green50,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.support_agent,
                        size: 48,
                        color: AppTheme.green800,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'হেল্পলাইন',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      SupportConfig.supportPhone,
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.green800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'সকাল ৯টা — রাত ৯টা',
                      style:
                          TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => _call(context),
              icon: const Icon(Icons.call),
              label: const Text('এখনই কল করুন'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Safety & Privacy info page.
class SafetyPrivacyScreen extends StatelessWidget {
  const SafetyPrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: const Text('সেফটি ও প্রাইভেসি')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _InfoCard(
            icon: Icons.shield_outlined,
            title: 'নিরাপদ যাত্রা',
            body:
                'রাইড শুরুর আগে ড্রাইভারের নাম, ছবি ও গাড়ির নম্বর মিলিয়ে নিন।',
          ),
          _InfoCard(
            icon: Icons.share_location,
            title: 'লাইভ ট্র্যাকিং',
            body:
                'চলন্ত রাইডের লোকেশন আপনার পরিবারের সাথে শেয়ার করতে পারেন।',
          ),
          _InfoCard(
            icon: Icons.lock_outline,
            title: 'প্রাইভেসি',
            body:
                'আপনার ফোন নম্বর শুধু রাইডের প্রয়োজনে ড্রাইভার দেখতে পান।',
          ),
          _InfoCard(
            icon: Icons.report_outlined,
            title: 'অভিযোগ',
            body:
                'কোনো সমস্যা হলে হেল্পলাইনে কল করুন: ${SupportConfig.supportPhone}',
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;

  const _InfoCard(
      {required this.icon,
      required this.title,
      required this.body});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.green50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon,
                  color: AppTheme.green800, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(body,
                      style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black87)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Simple settings page.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('অ্যাপ সেটিংস')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.notifications_outlined,
                  color: AppTheme.green800),
              title: const Text('নোটিফিকেশন'),
              subtitle:
                  const Text('রাইড আপডেট ও অফার'),
              trailing: Switch(
                value: true,
                onChanged: (_) {},
                activeColor: AppTheme.green800,
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.language,
                  color: AppTheme.green800),
              title: const Text('ভাষা'),
              subtitle: const Text('বাংলা'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              'CNG Ride v1.0',
              style:
                  TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}

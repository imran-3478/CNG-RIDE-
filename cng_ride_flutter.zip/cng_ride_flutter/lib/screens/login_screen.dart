import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import 'home_screen.dart';
import 'register_screen.dart';

/// Phone + 6-digit PIN login (same as web v3.7).
/// Phone -> synthetic email: 8801XXXXXXXXX@cngride.phone
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _pinCtrl = TextEditingController();
  bool _loading = false;
  String? _error;
  int _logoTaps = 0;

  Future<void> _login() async {
    final phone = AppConfig.normalizePhone(_phoneCtrl.text.trim());
    final pin = _pinCtrl.text.trim();

    if (phone == null) {
      setState(() => _error = 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)');
      return;
    }
    if (pin.length != 6 || !RegExp(r'^[0-9]{6}$').hasMatch(pin)) {
      setState(() => _error = '৬ সংখ্যার PIN দিন');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: AppConfig.phoneToEmail(phone),
        password: pin,
      );
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } on AuthException catch (e) {
      setState(() => _error = 'লগইন ব্যর্থ: ${e.message}');
    } catch (_) {
      setState(() => _error = 'সমস্যা হয়েছে, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _adminLogin() async {
    final emailCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    String? err;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Admin Login'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
              ),
              if (err != null) ...[
                const SizedBox(height: 8),
                Text(err!,
                    style: const TextStyle(color: Colors.red)),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('বাতিল'),
            ),
            ElevatedButton(
              onPressed: () async {
                try {
                  await Supabase.instance.client.auth
                      .signInWithPassword(
                    email: emailCtrl.text.trim(),
                    password: passCtrl.text,
                  );
                  if (!ctx.mounted) return;
                  Navigator.pop(ctx, true);
                } catch (_) {
                  setD(() => err = 'লগইন ব্যর্থ');
                }
              },
              child: const Text('লগইন'),
            ),
          ],
        ),
      ),
    );
    if (ok == true && mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    }
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _pinCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                GestureDetector(
                  onTap: () {
                    _logoTaps++;
                    if (_logoTaps >= 5) {
                      _logoTaps = 0;
                      _adminLogin();
                    }
                  },
                  child: const Icon(Icons.local_taxi,
                      size: 80,
                      color: Color(AppConfig.primaryGreen)),
                ),
                const SizedBox(height: 16),
                const Text(
                  'CNG Ride',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                ),
                const Text(
                  'টাঙ্গাইল',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18, color: Colors.grey),
                ),
                const SizedBox(height: 32),
                TextField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'মোবাইল নম্বর',
                    hintText: '01XXXXXXXXX',
                    prefixIcon: Icon(Icons.phone),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _pinCtrl,
                  keyboardType: TextInputType.number,
                  obscureText: true,
                  maxLength: 6,
                  decoration: const InputDecoration(
                    labelText: '৬ সংখ্যার PIN',
                    prefixIcon: Icon(Icons.lock),
                    border: OutlineInputBorder(),
                    counterText: '',
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _loading ? null : _login,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: _loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('লগইন', style: TextStyle(fontSize: 18)),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const RegisterScreen()),
                  ),
                  child: const Text('নতুন অ্যাকাউন্ট? রেজিস্টার করো'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

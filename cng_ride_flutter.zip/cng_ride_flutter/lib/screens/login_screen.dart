import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'home_screen.dart';

/// Phone + 6-digit PIN login (same as web v3.7)
/// Phone -> synthetic email: 8801XXXXXXXXX@cngride.phone
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _pinCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  String? _normalizePhone(String input) {
    var p = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (p.startsWith('880')) return p.length == 13 ? p : null;
    if (p.startsWith('01')) return p.length == 11 ? '88$p' : null;
    if (p.startsWith('1')) return p.length == 10 ? '880$p' : null;
    return null;
  }

  Future<void> _login() async {
    final phone = _normalizePhone(_phoneCtrl.text.trim());
    final pin = _pinCtrl.text.trim();

    if (phone == null) {
      setState(() => _error = 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)');
      return;
    }
    if (pin.length != 6 || !RegExp(r'^[0-9]{6}$').hasMatch(pin)) {
      setState(() => _error = '৬ সংখ্যার PIN দিন');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final email = '$phone@cngride.phone';
      await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: pin,
      );
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } on AuthException catch (e) {
      setState(() => _error = 'লগইন ব্যর্থ: ${e.message}');
    } catch (e) {
      setState(() => _error = 'সমস্যা হয়েছে, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _pinCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.local_taxi, size: 80, color: Color(0xFF0B7042)),
              const SizedBox(height: 16),
              const Text(
                'CNG Ride',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const Text(
                'টাঙ্গাইল',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'মোবাইল নম্বর',
                  hintText: '01XXXXXXXXX',
                  prefixIcon: Icon(Icons.phone),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _pinCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: '৬ সংখ্যার PIN',
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _loading ? null : _login,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('লগইন', style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

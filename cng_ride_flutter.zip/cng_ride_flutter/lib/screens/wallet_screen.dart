import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Driver wallet: balance, recharge request (bKash/Nagad trx ID),
/// pending requests, and transaction history.
/// Matches the web app's wallet + recharge modal.
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _loading = true;
  bool _sending = false;
  String? _error;
  String? _msg;
  double? _balance;
  List<Map<String, dynamic>> _pending = [];
  List<Map<String, dynamic>> _txns = [];
  final _amountCtrl = TextEditingController();
  final _trxCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _trxCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      final w = await Supabase.instance.client
          .from('wallets')
          .select('balance')
          .eq('driver_id', uid)
          .maybeSingle();
      List<Map<String, dynamic>> pending = [];
      List<Map<String, dynamic>> txns = [];
      try {
        final pr = await Supabase.instance.client
            .from('recharge_requests')
            .select('amount, trx_id, status, created_at')
            .eq('driver_id', uid)
            .order('created_at', ascending: false)
            .limit(5);
        pending = List<Map<String, dynamic>>.from(pr as List);
      } catch (_) {}
      try {
        final tr = await Supabase.instance.client
            .from('wallet_transactions')
            .select('type, amount, note, created_at')
            .eq('driver_id', uid)
            .order('created_at', ascending: false)
            .limit(15);
        txns = List<Map<String, dynamic>>.from(tr as List);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _balance = (w?['balance'] as num?)?.toDouble();
        _pending = pending;
        _txns = txns;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'লোড হয়নি';
        _loading = false;
      });
    }
  }

  Future<void> _sendRecharge() async {
    final amount = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    final trxId = _trxCtrl.text.trim();
    if (amount <= 0) {
      setState(() => _msg = 'সঠিক টাকার পরিমাণ দিন');
      return;
    }
    if (trxId.isEmpty) {
      setState(() => _msg = 'ট্রানজেকশন ID দিন');
      return;
    }
    setState(() {
      _sending = true;
      _msg = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      await Supabase.instance.client.from('recharge_requests').insert({
        'driver_id': uid,
        'amount': amount,
        'trx_id': trxId,
        'status': 'pending',
      });
      if (!mounted) return;
      _amountCtrl.clear();
      _trxCtrl.clear();
      setState(() {
        _sending = false;
        _msg = '✅ রিকোয়েস্ট পাঠানো হয়েছে। Admin verify করে ব্যালেন্স যোগ করে দেবেন।';
      });
      _load();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        _msg = 'পাঠানো যায়নি, আবার চেষ্টা করুন';
      });
    }
  }

  String _statusBn(String s) {
    switch (s) {
      case 'pending':
        return 'অপেক্ষমাণ';
      case 'approved':
        return 'অনুমোদিত';
      case 'rejected':
        return 'বাতিল';
      default:
        return s;
    }
  }

  String _dateBn(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final d = DateTime.parse(iso).toLocal();
      return '${d.day}/${d.month}/${d.year} ${d.hour}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ওয়ালেট')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Card(
                      color: Colors.teal.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            const Text('বর্তমান ব্যালেন্স',
                                style: TextStyle(
                                    fontSize: 15, color: Colors.grey)),
                            const SizedBox(height: 4),
                            Text(
                              _balance == null
                                  ? '—'
                                  : '৳${_balance!.toStringAsFixed(0)}',
                              style: const TextStyle(
                                  fontSize: 36,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.teal),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Available হতে কমপক্ষে ৳50 লাগবে',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text('💰 রিচার্জ রিকোয়েস্ট',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    const Text(
                      'বিকাশ/নগদে টাকা পাঠিয়ে নিচে পরিমাণ ও ট্রানজেকশন ID দিন।',
                      style:
                          TextStyle(fontSize: 13, color: Colors.grey),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _amountCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'টাকার পরিমাণ (৳)',
                        prefixIcon: Icon(Icons.payments),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _trxCtrl,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'ট্রানজেকশন ID (TrxID)',
                        prefixIcon: Icon(Icons.receipt_long),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: _sending ? null : _sendRecharge,
                      style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                              vertical: 14)),
                      child: _sending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2))
                          : const Text('রিচার্জ রিকোয়েস্ট পাঠান',
                              style: TextStyle(fontSize: 17)),
                    ),
                    if (_msg != null) ...[
                      const SizedBox(height: 8),
                      Text(_msg!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: _msg!.startsWith('✅')
                                  ? Colors.green
                                  : Colors.red)),
                    ],
                    if (_pending.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      const Text('সাম্প্রতিক রিকোয়েস্ট',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      ..._pending.map((r) {
                        final st =
                            (r['status'] ?? '').toString();
                        return Card(
                          child: ListTile(
                            leading: Icon(
                              st == 'approved'
                                  ? Icons.check_circle
                                  : st == 'rejected'
                                      ? Icons.cancel
                                      : Icons.hourglass_empty,
                              color: st == 'approved'
                                  ? Colors.green
                                  : st == 'rejected'
                                      ? Colors.red
                                      : Colors.orange,
                            ),
                            title: Text(
                                '৳${(r['amount'] as num?)?.toStringAsFixed(0) ?? '—'}'),
                            subtitle: Text(
                                'TrxID: ${r['trx_id'] ?? '—'}\n${_dateBn(r['created_at']?.toString())}'),
                            trailing: Text(_statusBn(st),
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                          ),
                        );
                      }),
                    ],
                    if (_txns.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      const Text('লেনদেনের হিস্ট্রি',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      ..._txns.map((t) {
                        final amt =
                            (t['amount'] as num?)?.toDouble() ?? 0;
                        final credit = amt > 0;
                        final type = (t['type'] ?? '').toString();
                        final label = type == 'recharge'
                            ? 'রিচার্জ'
                            : type == 'commission'
                                ? 'কমিশন'
                                : 'সমন্বয়';
                        return ListTile(
                          dense: true,
                          leading: Icon(
                            credit
                                ? Icons.arrow_downward
                                : Icons.arrow_upward,
                            color: credit
                                ? Colors.green
                                : Colors.red,
                          ),
                          title: Text(label),
                          subtitle: Text(
                              '${(t['note'] ?? '').toString()} • ${_dateBn(t['created_at']?.toString())}',
                              style:
                                  const TextStyle(fontSize: 12)),
                          trailing: Text(
                            '${credit ? '+' : ''}৳${amt.toStringAsFixed(0)}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: credit
                                    ? Colors.green
                                    : Colors.red,
                                fontSize: 16),
                          ),
                        );
                      }),
                    ],
                    if (_error != null) ...[
                      const SizedBox(height: 12),
                      Text(_error!,
                          style:
                              const TextStyle(color: Colors.red),
                          textAlign: TextAlign.center),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
    );
  }
}

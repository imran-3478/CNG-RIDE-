import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../widgets/passenger_main.dart';
import 'driver_home.dart';
import 'login_screen.dart';

/// Routes the logged-in user to the passenger or driver home
/// based on profiles.user_type.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _userType;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      final row = await Supabase.instance.client
          .from('profiles')
          .select('user_type')
          .eq('id', uid)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _userType = (row?['user_type'] as String?) ?? 'passenger';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'প্রোফাইল লোড হয়নি, আবার লগইন করুন');
    }
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_error!),
              const SizedBox(height: 16),
              ElevatedButton(
                  onPressed: _logout, child: const Text('লগইন পেজে যাও')),
            ],
          ),
        ),
      );
    }
    if (_userType == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_userType == 'driver') {
      return const DriverHome();
    }
    return const PassengerMain();
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Past rides for driver or passenger.
/// Matches the web app's "My Rides" list.
class RideHistoryScreen extends StatefulWidget {
  const RideHistoryScreen({super.key});

  @override
  State<RideHistoryScreen> createState() => _RideHistoryScreenState();
}

class _RideHistoryScreenState extends State<RideHistoryScreen>
    with SingleTickerProviderStateMixin {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rides = [];
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) throw Exception('no-session');
      final prof = await Supabase.instance.client
          .from('profiles')
          .select('user_type')
          .eq('id', uid)
          .maybeSingle();
      final isDriver =
          (prof?['user_type'] as String?) == 'driver';
      final data = await Supabase.instance.client
          .from('ride_requests')
          .select()
          .eq(isDriver ? 'driver_id' : 'passenger_id', uid)
          .order('created_at', ascending: false)
          .limit(30);
      if (!mounted) return;
      setState(() {
        _rides = List<Map<String, dynamic>>.from(data as List);
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'লোড হয়নি';
        _loading = false;
      });
    }
  }

  String _statusBn(String s) {
    switch (s) {
      case 'pending':
        return 'অপেক্ষমাণ';
      case 'accepted':
        return 'গৃহীত';
      case 'ongoing':
        return 'চলমান';
      case 'completed':
        return 'সম্পন্ন';
      case 'cancelled':
        return 'বাতিল';
      case 'rejected':
        return 'প্রত্যাখ্যাত';
      default:
        return s;
    }
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'completed':
        return Colors.green;
      case 'cancelled':
      case 'rejected':
        return Colors.red;
      case 'ongoing':
      case 'accepted':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  String _dateBn(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final d = DateTime.parse(iso).toLocal();
      return '${d.day}/${d.month}/${d.year}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('আমার রাইড'),
        bottom: TabBar(
          controller: _tabCtrl,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: 'সাম্প্রতিক'),
            Tab(text: 'সমস্ত'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : TabBarView(
                  controller: _tabCtrl,
                  children: [
                    _list(_rides.take(5).toList()),
                    _list(_rides),
                  ],
                ),
    );
  }

  Widget _list(List<Map<String, dynamic>> rides) {
    if (rides.isEmpty) {
      return const Center(
          child: Text('কোনো রাইড নেই',
              style: TextStyle(fontSize: 16, color: Colors.grey)));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: rides.length,
                        itemBuilder: (_, i) {
                          final r = rides[i];
                          final status =
                              (r['status'] ?? '').toString();
                          final dest = (r['destination_address'] ??
                                  r['destination'] ??
                                  '—')
                              .toString();
                          final fare = r['estimated_fare'] ??
                              r['fare'];
                          final km = r['distance_km'];
                          return Card(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            child: ListTile(
                              leading: Icon(
                                Icons.directions_car,
                                color: _statusColor(status),
                                size: 32,
                              ),
                              title: Text(
                                dest.length > 50
                                    ? '${dest.substring(0, 50)}…'
                                    : dest,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w500),
                              ),
                              subtitle: Text(
                                '${_dateBn(r['created_at']?.toString())}'
                                '${km != null ? ' • ${(km as num).toStringAsFixed(1)} কিমি' : ''}'
                                '${fare != null ? ' • ৳${(fare as num).toStringAsFixed(0)}' : ''}',
                              ),
                              trailing: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: _statusColor(status)
                                      .withOpacity(0.12),
                                  borderRadius:
                                      BorderRadius.circular(12),
                                ),
                                child: Text(
                                  _statusBn(status),
                                  style: TextStyle(
                                      color:
                                          _statusColor(status),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}

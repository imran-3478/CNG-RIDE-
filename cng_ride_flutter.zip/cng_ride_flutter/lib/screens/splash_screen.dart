import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../screens/home_screen.dart';
import '../screens/login_screen.dart';
import '../widgets/app_theme.dart';

/// Splash screen: green gradient, logo, tagline.
/// Shows briefly, then routes based on session.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      final session =
          Supabase.instance.client.auth.currentSession;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => session != null
              ? const HomeScreen()
              : const LoginScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration:
            const BoxDecoration(gradient: AppTheme.gradient),
        child: SafeArea(
          child: Column(
            children: [
              const Spacer(flex: 2),
              const CngLogo(size: 110),
              const SizedBox(height: 24),
              RichText(
                textAlign: TextAlign.center,
                text: const TextSpan(
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  children: [
                    TextSpan(text: 'CNG '),
                    TextSpan(
                      text: 'Ride',
                      style: TextStyle(color: AppTheme.amber),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'কাছের CNG খুঁজুন',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white70,
                ),
              ),
              const Spacer(flex: 3),
              const Text(
                'নিরাপদ যাত্রা, সবার জন্য',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white60,
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

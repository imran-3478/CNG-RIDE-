import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../config.dart';
import '../services/location_service.dart';
import '../widgets/map_widgets.dart';

/// Driver trip screen: pickup map, Google Maps navigation,
/// ride completion with fare confirm.
class DriverTripScreen extends StatefulWidget {
  final String rideId;
  final Map<String, dynamic>? initialRide;
  const DriverTripScreen(
      {super.key, required this.rideId, this.initialRide});

  @override
  State<DriverTripScreen> createState() => _DriverTripScreenState();
}

class _DriverTripScreenState extends State<DriverTripScreen> {
  final _mapCtrl = MapController();
  Map<String, dynamic>? _ride;
  Position? _myPos;
  String? _error;
  bool _completing = false;
  bool _isSatellite = false;

  StreamSubscription<Position>? _posSub;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _init();
  }

  Future<void> _init() async {
    // Use the passed ride data immediately so the screen never stays blank.
    if (widget.initialRide != null) {
      setState(() => _ride = widget.initialRide);
      final plat =
          (widget.initialRide!['pickup_lat'] as num?)?.toDouble();
      final plng =
          (widget.initialRide!['pickup_lng'] as num?)?.toDouble();
      if (plat != null && plng != null) {
        _mapCtrl.move(LatLng(plat, plng), 15);
      }
    }
    try {
      final ride = await Supabase.instance.client
          .from('ride_requests')
          .select()
          .eq('id', widget.rideId)
          .maybeSingle();
      if (!mounted) return;
      if (ride == null) {
        // Keep the passed data if the refetch is blocked; only error
        // when we have nothing to show.
        if (_ride == null) {
          setState(() => _error = 'রাইড পাওয়া যায়নি');
        }
        return;
      }
      setState(() => _ride = ride);
      final plat = (ride['pickup_lat'] as num?)?.toDouble();
      final plng = (ride['pickup_lng'] as num?)?.toDouble();
      if (plat != null && plng != null) {
        _mapCtrl.move(LatLng(plat, plng), 15);
      }
    } catch (_) {
      // Only show error when we have no data at all; the passed-in
      // ride stays visible otherwise.
      if (mounted && _ride == null) {
        setState(() => _error = 'লোড করতে সমস্যা হয়েছে');
      }
    }
    final pos = await LocationService.currentPosition();
    if (mounted && pos != null) setState(() => _myPos = pos);
    _posSub = LocationService.positionStream().listen((p) {
      if (mounted) setState(() => _myPos = p);
    });
  }

  Future<void> _navigateToPickup() async {
    final lat = (_ride?['pickup_lat'] as num?)?.toDouble();
    final lng = (_ride?['pickup_lng'] as num?)?.toDouble();
    if (lat == null || lng == null) return;
    final uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _completeRide() async {
    final fare = (_ride?['estimated_fare'] as num?)?.toDouble();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Ride শেষ করো?'),
        content: Text(
            'ভাড়া: ৳${fare?.toStringAsFixed(0) ?? '?'} — যাত্রীর কাছ থেকে নেওয়া হয়েছে তো?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('না'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('হ্যাঁ, শেষ'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _completing = true);
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      await Supabase.instance.client
          .from('ride_requests')
          .update({'status': 'completed'}).eq('id', widget.rideId);
      // Driver becomes available again (same as web).
      await Supabase.instance.client.from('drivers').update({
        'available': true,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', uid);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ride সম্পন্ন!')));
      Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'সম্পন্ন করা যায়নি');
        setState(() => _completing = false);
      }
    }
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _mapCtrl.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('ট্রিপ')),
        body: Center(child: Text(_error!)),
      );
    }
    if (_ride == null) {
      return const Scaffold(
          body: Center(child: CircularProgressIndicator()));
    }

    final plat = (_ride!['pickup_lat'] as num?)?.toDouble();
    final plng = (_ride!['pickup_lng'] as num?)?.toDouble();
    final dest = (_ride!['destination_address'] ?? '').toString();
    final fare =
        (_ride!['estimated_fare'] as num?)?.toStringAsFixed(0) ?? '?';

    final markers = <Marker>[
      if (plat != null && plng != null)
        Marker(
          point: LatLng(plat, plng),
          width: 44,
          height: 44,
          child: const Icon(Icons.location_pin,
              color: Colors.red, size: 44),
        ),
      if (_myPos != null)
        Marker(
          point: LatLng(_myPos!.latitude, _myPos!.longitude),
          width: 24,
          height: 24,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
          ),
        ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('ট্রিপ চলছে')),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapCtrl,
            options: const MapOptions(
              initialCenter:
                  LatLng(AppConfig.tangailLat, AppConfig.tangailLng),
              initialZoom: 14,
            ),
            children: [
              buildTileLayer(_isSatellite),
              MarkerLayer(markers: markers),
            ],
          ),
          SatelliteToggle(
            isSatellite: _isSatellite,
            onToggle: () =>
                setState(() => _isSatellite = !_isSatellite),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'গন্তব্য: ${dest.length > 70 ? '${dest.substring(0, 70)}…' : dest}',
                      style:
                          const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text('ভাড়া: ৳$fare',
                        style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _navigateToPickup,
                      icon: const Icon(Icons.navigation),
                      label: const Text('Google Maps-এ Navigate করো'),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed:
                          _completing ? null : _completeRide,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            vertical: 14),
                      ),
                      child: _completing
                          ? const CircularProgressIndicator(
                              color: Colors.white)
                          : const Text('Ride শেষ করুন / Fare Confirm',
                              style: TextStyle(fontSize: 16)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

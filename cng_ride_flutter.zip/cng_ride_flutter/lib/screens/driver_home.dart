import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:vibration/vibration.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../config.dart';
import '../services/location_service.dart';
import '../services/push_service.dart';
import '../services/background_location.dart';
import '../widgets/app_drawer.dart';
import '../widgets/app_theme.dart';
import 'driver_trip_screen.dart';
import 'login_screen.dart';
import 'wallet_screen.dart';

/// Driver home: Available/Busy toggle, wallet gate, live location updates,
/// incoming ride requests with repeating sound + vibration alert.
class DriverHome extends StatefulWidget {
  const DriverHome({super.key});

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  bool _available = false;
  double? _balance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _pendingRequests = [];

  StreamSubscription<Position>? _posSub;
  RealtimeChannel? _channel;
  Timer? _alertTimer;
  final _audio = AudioPlayer();
  Map<String, dynamic>? _ringingRequest;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      // Ensure drivers row exists (same as web).
      final existing = await Supabase.instance.client
          .from('drivers')
          .select('available')
          .eq('id', uid)
          .maybeSingle();
      if (existing == null) {
        final prof = await Supabase.instance.client
            .from('profiles')
            .select('full_name, phone')
            .eq('id', uid)
            .maybeSingle();
        await Supabase.instance.client.from('drivers').insert({
          'id': uid,
          'vehicle_name':
              (prof?['full_name'] ?? 'CNG Driver').toString(),
          'vehicle_number': (prof?['phone'] ?? '').toString(),
          'available': false,
        });
      }
      await _refreshState();
      _subscribeRequests();
      // Register this phone for push notifications (ride-request alerts
      // even when the app is in background).
      PushService.registerDriverToken();
      // Catch requests that arrived while away.
      await _loadPendingRequests();
    } catch (_) {
      if (mounted) setState(() => _error = 'লোড করতে সমস্যা হয়েছে');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refreshState() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      final drv = await Supabase.instance.client
          .from('drivers')
          .select('available')
          .eq('id', uid)
          .maybeSingle();
      final wallet = await Supabase.instance.client
          .from('wallets')
          .select('balance')
          .eq('driver_id', uid)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _available = (drv?['available'] as bool?) ?? false;
        _balance = (wallet?['balance'] as num?)?.toDouble();
      });
      if (_available) {
        _startLocationSharing();
        WakelockPlus.enable();
      }
    } catch (_) {}
  }

  void _subscribeRequests() {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    _channel = Supabase.instance.client.channel('driver-req-$uid');
    _channel!.onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: 'ride_requests',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'driver_id',
        value: uid,
      ),
      callback: (payload) {
        final rec = payload.newRecord;
        if (rec['status']?.toString() == 'pending' && mounted) {
          _onIncomingRequest(rec);
        }
      },
    );
    _channel!.subscribe();
  }

  Future<void> _loadPendingRequests() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      final rows = await Supabase.instance.client
          .from('ride_requests')
          .select()
          .eq('driver_id', uid)
          .eq('status', 'pending')
          .order('created_at', ascending: false)
          .limit(5);
      if (!mounted) return;
      setState(() {
        _pendingRequests =
            (rows as List).cast<Map<String, dynamic>>();
      });
      if (_pendingRequests.isNotEmpty && _ringingRequest == null) {
        _onIncomingRequest(_pendingRequests.first);
      }
    } catch (_) {}
  }

  void _onIncomingRequest(Map<String, dynamic> req) {
    if (_ringingRequest != null) return; // already ringing
    setState(() => _ringingRequest = req);
    _startAlertLoop();
    _showRequestDialog(req);
  }

  void _startAlertLoop() {
    _alertTimer?.cancel();
    _alertLoopTick();
    // Repeat every 4s until accept/reject (same as web v3.8).
    _alertTimer =
        Timer.periodic(const Duration(seconds: 4), (_) => _alertLoopTick());
  }

  Future<void> _alertLoopTick() async {
    try {
      await _audio.play(AssetSource('audio/alert.wav'));
    } catch (_) {}
    try {
      if (await Vibration.hasVibrator() ?? false) {
        await Vibration.vibrate(pattern: [0, 600, 300, 600]);
      }
    } catch (_) {}
  }

  void _stopAlert() {
    _alertTimer?.cancel();
    _alertTimer = null;
    _audio.stop();
    if (mounted) setState(() => _ringingRequest = null);
  }

  void _showRequestDialog(Map<String, dynamic> req) {
    final dest = (req['destination_address'] ?? '').toString();
    final fare = (req['estimated_fare'] as num?)?.toStringAsFixed(0) ?? '?';
    final km = (req['distance_km'] as num?)?.toStringAsFixed(1) ?? '?';
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('নতুন রাইড রিকোয়েস্ট!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('গন্তব্য: ${dest.length > 80 ? '${dest.substring(0, 80)}…' : dest}'),
            const SizedBox(height: 8),
            Text('দূরত্ব: $km কিমি'),
            Text('আনুমানিক ভাড়া: ৳$fare',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _reject(req['id'].toString());
            },
            child: const Text('বাতিল',
                style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _accept(req);
            },
            child: const Text('Accept'),
          ),
        ],
      ),
    );
  }

  Future<void> _accept(Map<String, dynamic> req) async {
    _stopAlert();
    final rideId = req['id'].toString();
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      // Wallet gate: ৳50-এর কম থাকলে ride accept করা যাবে না।
      final wallet = await Supabase.instance.client
          .from('wallets')
          .select('balance')
          .eq('driver_id', uid)
          .maybeSingle();
      final bal =
          (wallet?['balance'] as num?)?.toDouble() ?? 0;
      if (!mounted) return;
      if (bal < AppConfig.minWalletBalance) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(
                  'ব্যালেন্স ৳${bal.toStringAsFixed(0)} — রাইড accept করতে ৳${AppConfig.minWalletBalance.toStringAsFixed(0)} লাগবে। রিচার্জ করুন।')),
        );
        return;
      }
      await Supabase.instance.client
          .from('ride_requests')
          .update({'status': 'accepted'}).eq('id', rideId);
      await Supabase.instance.client.from('drivers').update({
        'available': false,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', uid);
      if (!mounted) return;
      setState(() => _available = false);
      _stopLocationStream();
      // Pass the ride data directly — no re-query needed (avoids
      // blank screen if the refetch is blocked or slow).
      final rideData = Map<String, dynamic>.from(req)
        ..['status'] = 'accepted';
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) =>
                DriverTripScreen(rideId: rideId, initialRide: rideData)),
      ).then((_) => _refreshState());
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Accept করা যায়নি')));
      }
    }
  }

  Future<void> _reject(String rideId) async {
    _stopAlert();
    try {
      await Supabase.instance.client
          .from('ride_requests')
          .update({'status': 'rejected'}).eq('id', rideId);
      if (mounted) {
        setState(() => _pendingRequests
            .removeWhere((r) => r['id'].toString() == rideId));
      }
    } catch (_) {}
  }

  /// Starts live location sharing (foreground stream + background service).
  /// Requests location permission first — without it the position stream
  /// emits an error that crashes the app.
  Future<void> _startLocationSharing() async {
    _posSub?.cancel();
    _posSub = null;
    if (!await LocationService.ensurePermission()) return;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return;
    _posSub = LocationService.positionStream(distanceFilterMeters: 25)
        .listen((pos) async {
      try {
        await Supabase.instance.client.from('drivers').update({
          'latitude': pos.latitude,
          'longitude': pos.longitude,
          'updated_at': DateTime.now().toIso8601String(),
        }).eq('id', uid);
      } catch (_) {}
    });
    // Keep sharing location even when the app is minimized.
        // DIAGNOSTIC-TEST complete: FGS was the culprit (missing notification
        // channel). Re-enabled with fix.
        BackgroundLocation.start(uid);
  }

  void _stopLocationStream() {
    _posSub?.cancel();
    _posSub = null;
  }

  Future<void> _toggleAvailable() async {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    if (!_available) {
      // Turning ON: wallet gate ৳50 (same as web).
      final wallet = await Supabase.instance.client
          .from('wallets')
          .select('balance')
          .eq('driver_id', uid)
          .maybeSingle();
      final bal = (wallet?['balance'] as num?)?.toDouble() ?? 0;
      if (!mounted) return;
      if (bal < AppConfig.minWalletBalance) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(
                  'ব্যালেন্স ৳${bal.toStringAsFixed(0)} — Available হতে ৳${AppConfig.minWalletBalance.toStringAsFixed(0)} লাগবে। আগে রিচার্জ করুন।')),
        );
        return;
      }
    }
    try {
      final newStatus = !_available;
      await Supabase.instance.client.from('drivers').update({
        'available': newStatus,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', uid);
      if (!mounted) return;
      setState(() => _available = newStatus);
      if (newStatus) {
        _startLocationSharing();
        WakelockPlus.enable();
        _loadPendingRequests();
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Available — রিকোয়েস্ট আসবে')));
      } else {
        _stopLocationStream();
        WakelockPlus.disable();
        BackgroundLocation.stop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('স্ট্যাটাস বদলানো যায়নি')));
      }
    }
  }

  Future<void> _logout() async {
    _stopAlert();
    _stopLocationStream();
    WakelockPlus.disable();
    BackgroundLocation.stop();
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  void dispose() {
    _stopAlert();
    _stopLocationStream();
    if (_channel != null) {
      Supabase.instance.client.removeChannel(_channel!);
    }
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
          body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      drawer: const AppDrawer(isDriver: true),
      body: CustomScrollView(
        slivers: [
          // Green gradient header
          SliverAppBar(
            expandedHeight: 190,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: AppTheme.gradient,
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Text(
                          'ড্রাইভার ড্যাশবোর্ড',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _available
                              ? '🟢 Available — যাত্রী খুঁজছি…'
                              : '⚪ Busy — রিকোয়েস্ট আসবে না',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                  icon: const Icon(Icons.logout),
                  onPressed: _logout),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  // Wallet card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.green50,
                              borderRadius:
                                  BorderRadius.circular(14),
                            ),
                            child: const Icon(
                              Icons.account_balance_wallet,
                              size: 32,
                              color: AppTheme.green800,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'ওয়ালেট ব্যালেন্স',
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 13),
                                ),
                                Text(
                                  '৳${(_balance ?? 0).toStringAsFixed(0)}',
                                  style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: AppTheme.green800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    const WalletScreen(),
                              ),
                            ),
                            child: const Text('রিচার্জ'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Available toggle - big and beautiful
                  Card(
                    color: _available
                        ? AppTheme.green800
                        : Colors.white,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: _toggleAvailable,
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Row(
                          children: [
                            Container(
                              padding:
                                  const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _available
                                    ? Colors.white
                                        .withOpacity(0.2)
                                    : AppTheme.green50,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                _available
                                    ? Icons.check_circle
                                    : Icons.pause_circle,
                                size: 30,
                                color: _available
                                    ? Colors.white
                                    : AppTheme.green800,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _available
                                        ? 'Available'
                                        : 'Busy',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight:
                                          FontWeight.bold,
                                      color: _available
                                          ? Colors.white
                                          : Colors.black87,
                                    ),
                                  ),
                                  Text(
                                    _available
                                        ? 'যাত্রী খুঁজছি…'
                                        : 'ট্যাপ করে Available হোন',
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: _available
                                          ? Colors.white70
                                          : Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Switch(
                              value: _available,
                              onChanged: (_) =>
                                  _toggleAvailable(),
                              activeColor: Colors.white,
                              activeTrackColor: AppTheme.amber,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!,
                        style: const TextStyle(
                            color: Colors.red)),
                  ],
                  if (_available) ...[
                    const SizedBox(height: 14),
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Icon(Icons.notifications_active,
                                color: AppTheme.green800),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'রাইড রিকোয়েস্ট এলে শব্দ + vibration বাজবে।',
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  const Center(
                    child: Text(
                      'রাইড শেষে ভাড়া confirm করতে ভুলো না।',
                      style: TextStyle(
                          color: Colors.grey, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import 'home_screen.dart';

/// Phone + PIN registration (same as web v3.7).
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _vehicleCtrl = TextEditingController();
  final _pinCtrl = TextEditingController();
  final _pin2Ctrl = TextEditingController();
  String _type = 'passenger'; // passenger | driver
  bool _loading = false;
  String? _error;

  Future<void> _register() async {
    final name = _nameCtrl.text.trim();
    final phone = AppConfig.normalizePhone(_phoneCtrl.text.trim());
    final vehicle = _vehicleCtrl.text.trim();
    final pin = _pinCtrl.text.trim();
    final pin2 = _pin2Ctrl.text.trim();

    if (name.isEmpty) {
      setState(() => _error = 'নাম দিন');
      return;
    }
    if (phone == null) {
      setState(() => _error = 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)');
      return;
    }
    if (_type == 'driver' && vehicle.isEmpty) {
      setState(() => _error = 'গাড়ির নম্বর দিন');
      return;
    }
    if (pin.length != 6 || !RegExp(r'^[0-9]{6}$').hasMatch(pin)) {
      setState(() => _error = '৬ সংখ্যার PIN দিন');
      return;
    }
    if (pin != pin2) {
      setState(() => _error = 'PIN মিলছে না, আবার দিন');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final client = Supabase.instance.client;
      final res = await client.auth.signUp(
        email: AppConfig.phoneToEmail(phone),
        password: pin,
      );
      final user = res.user;
      if (user == null) throw Exception('signup-failed');

      await client.from('profiles').upsert({
        'id': user.id,
        'full_name': name,
        'phone': phone,
        'user_type': _type,
        'vehicle_number': _type == 'driver' ? vehicle : null,
      }, onConflict: 'id');

      if (_type == 'driver') {
        // Ensure a drivers row exists (web app does select-then-insert).
        try {
          await client.from('drivers').insert({
            'id': user.id,
            'vehicle_name': name,
            'vehicle_number': vehicle,
            'available': false,
          });
        } catch (_) {
          // Row may already exist — ignore.
        }
      }

      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (_) => false,
      );
    } on AuthException catch (e) {
      setState(() => _error = 'রেজিস্টার ব্যর্থ: ${e.message}');
    } catch (_) {
      setState(() => _error = 'সমস্যা হয়েছে, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _vehicleCtrl.dispose();
    _pinCtrl.dispose();
    _pin2Ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('রেজিস্টার')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(
                  labelText: 'নাম',
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'মোবাইল নম্বর',
                  hintText: '01XXXXXXXXX',
                  prefixIcon: Icon(Icons.phone),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('আপনি কে?', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                      value: 'passenger',
                      label: Text('যাত্রী'),
                      icon: Icon(Icons.person)),
                  ButtonSegment(
                      value: 'driver',
                      label: Text('ড্রাইভার'),
                      icon: Icon(Icons.local_taxi)),
                ],
                selected: {_type},
                onSelectionChanged: (s) =>
                    setState(() => _type = s.first),
              ),
              if (_type == 'driver') ...[
                const SizedBox(height: 16),
                TextField(
                  controller: _vehicleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'গাড়ির নম্বর',
                    prefixIcon: Icon(Icons.directions_car),
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              TextField(
                controller: _pinCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: '৬ সংখ্যার PIN',
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _pin2Ctrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: 'PIN আবার দিন',
                  prefixIcon: Icon(Icons.lock_outline),
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _loading ? null : _register,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('রেজিস্টার',
                        style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'services/push_service.dart';
import 'services/background_location.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabaseKey,
  );

  // Push notifications (best-effort; app works without it).
  await PushService.init();
  // Background location service (driver Available → shares location
  // even when the app is minimized).
  await BackgroundLocation.init();

  runApp(const CngRideApp());
}

class CngRideApp extends StatelessWidget {
  const CngRideApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CNG Ride',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(AppConfig.primaryGreen),
        ),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}

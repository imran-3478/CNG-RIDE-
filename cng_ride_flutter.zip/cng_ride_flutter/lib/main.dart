import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://icfzimjduanfzwpkbtdu.supabase.co',
    anonKey: 'sb_publishable_2ZmJLbota_YQZ7rDKqV6ew_ApWVxoak',
  );

  runApp(const CngRideApp());
}

class CngRideApp extends StatelessWidget {
  const CngRideApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CNG Ride',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0B7042), // emerald green
        ),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}

/// App-wide constants, mirroring the web app (v5.2).
class AppConfig {
  static const supabaseUrl = 'https://icfzimjduanfzwpkbtdu.supabase.co';
  static const supabaseKey = 'sb_publishable_2ZmJLbota_YQZ7rDKqV6ew_ApWVxoak';

  static const farePerKm = 20.0;
  static const minFare = 20.0;
  static const minWalletBalance = 50.0;

  static const tangailLat = 24.2513;
  static const tangailLng = 89.9167;

  static const phoneEmailDomain = 'cngride.phone';

  static const primaryGreen = 0xFF0B7042;

  /// Admin emails (same as web app) — see the admin panel.
  static const adminEmails = ['emrankhan172@gmail.com'];

  static bool isAdminEmail(String? email) =>
      email != null &&
      adminEmails.contains(email.trim().toLowerCase());

  static String phoneToEmail(String phone880) => '$phone880@$phoneEmailDomain';

  /// Normalize BD mobile number to 8801XXXXXXXXX, or null if invalid.
  static String? normalizePhone(String input) {
    final p = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (p.startsWith('880')) return p.length == 13 ? p : null;
    if (p.startsWith('01')) return p.length == 11 ? '88$p' : null;
    if (p.startsWith('1')) return p.length == 10 ? '880$p' : null;
    return null;
  }

  static double estimateFare(double km) {
    final f = km * farePerKm;
    final capped = f < minFare ? minFare : f;
    return capped.roundToDouble();
  }
}

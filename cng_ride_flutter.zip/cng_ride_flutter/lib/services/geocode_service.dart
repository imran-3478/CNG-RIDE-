import 'dart:convert';

import 'package:http/http.dart' as http;

/// Destination search via Nominatim (same as the web app). Free, no API key.
class PlaceResult {
  final String name;
  final double lat;
  final double lng;

  PlaceResult({required this.name, required this.lat, required this.lng});
}

class GeocodeService {
  static Future<List<PlaceResult>> search(String query) async {
    if (query.trim().length < 3) return [];
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
        'format': 'jsonv2',
        'limit': '5',
        'countrycodes': 'bd',
        'q': query.trim(),
      });
      final res = await http.get(uri, headers: {
        'User-Agent': 'CNG-Ride-App/1.0',
        'Accept': 'application/json',
      }).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return [];
      final List data = json.decode(res.body) as List;
      return data
          .map((e) => PlaceResult(
                name: (e['display_name'] ?? '').toString(),
                lat: double.tryParse(e['lat'].toString()) ?? 0,
                lng: double.tryParse(e['lon'].toString()) ?? 0,
              ))
          .where((p) => p.lat != 0)
          .toList();
    } catch (_) {
      return [];
    }
  }
}

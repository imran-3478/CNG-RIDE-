import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Background message handler — must be a top-level function.
/// For notification-payload messages the system tray shows the
/// notification automatically; we only need Firebase initialized here.
@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

/// Push notifications via Firebase Cloud Messaging.
/// - Foreground: shows a heads-up notification via flutter_local_notifications.
/// - Background / terminated: system tray shows it automatically.
/// - The FCM token is saved to drivers.fcm_token so the server can
///   target this driver's phone on new ride requests.
class PushService {
  static final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      await Firebase.initializeApp();
      FirebaseMessaging.onBackgroundMessage(firebaseBackgroundHandler);

      const androidSettings =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      await _local.initialize(
          const InitializationSettings(android: androidSettings));

      const channel = AndroidNotificationChannel(
        'ride_requests',
        'Ride Requests',
        description: 'নতুন রাইড রিকোয়েস্ট অ্যালার্ট',
        importance: Importance.high,
      );
      await _local
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);

      FirebaseMessaging.onMessage.listen((msg) {
        final n = msg.notification;
        if (n == null) return;
        _local.show(
          n.hashCode,
          n.title,
          n.body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'ride_requests',
              'Ride Requests',
              importance: Importance.high,
              priority: Priority.high,
            ),
          ),
        );
      });

      // Keep the saved token fresh.
      FirebaseMessaging.instance.onTokenRefresh.listen((token) {
        _saveToken(token);
      });
    } catch (_) {
      // Push is best-effort; the app must work without it.
    }
  }

  /// Ask for notification permission and save the FCM token for this driver.
  /// Call after the driver is logged in (DriverHome init).
  static Future<void> registerDriverToken() async {
    try {
      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(
          alert: true, badge: true, sound: true);
      final token = await messaging.getToken();
      if (token != null) await _saveToken(token);
    } catch (_) {}
  }

  static Future<void> _saveToken(String token) async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      await Supabase.instance.client
          .from('drivers')
          .update({'fcm_token': token}).eq('id', uid);
    } catch (_) {
      // Column may not exist yet — the user runs the ALTER TABLE SQL.
    }
  }
}

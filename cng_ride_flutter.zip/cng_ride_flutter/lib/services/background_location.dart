import 'dart:async';
import 'dart:ui';

import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

/// Runs in a background isolate as an Android foreground service.
/// Keeps pushing the driver's location to Supabase every 15 seconds
/// while the driver is Available — even when the app is minimized.
/// A persistent notification ("CNG Ride — Available") shows in the tray.
@pragma('vm:entry-point')
void backgroundLocationEntryPoint(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabaseKey,
  );

  String? driverId;
  bool available = false;

  service.on('driver').listen((event) {
    driverId = event?['driverId'] as String?;
    available = (event?['available'] as bool?) ?? false;
  });

  Timer.periodic(const Duration(seconds: 15), (_) async {
    if (!available || driverId == null) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 10),
        ),
      );
      await Supabase.instance.client.from('drivers').update({
        'latitude': pos.latitude,
        'longitude': pos.longitude,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', driverId!);
      if (service is AndroidServiceInstance) {
        service.setForegroundNotificationInfo(
          title: 'CNG Ride — Available',
          content: 'লোকেশন শেয়ার হচ্ছে...',
        );
      }
    } catch (_) {
      // Best-effort: next tick retries.
    }
  });

  service.on('stop').listen((_) => service.stopSelf());
}

class BackgroundLocation {
  /// Call once in main() before runApp().
  static Future<void> init() async {
    final service = FlutterBackgroundService();
    await service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: backgroundLocationEntryPoint,
        autoStart: false,
        autoStartOnBoot: false,
        isForegroundMode: true,
        // Android 14+ requires declaring the location foreground-service type.
        foregroundServiceTypes: [AndroidForegroundType.location],
        notificationChannelId: 'cng_location',
        initialNotificationTitle: 'CNG Ride',
        initialNotificationContent: 'লোকেশন শেয়ার হচ্ছে',
        foregroundServiceNotificationId: 888,
      ),
      iosConfiguration: IosConfiguration(
        autoStart: false,
        onForeground: backgroundLocationEntryPoint,
      ),
    );
  }

  /// Start sharing location for this driver (call when Available turns ON).
  static Future<void> start(String driverId) async {
    try {
      final service = FlutterBackgroundService();
      if (!await service.isRunning()) {
        await service.startService();
        // Let the isolate register its listeners before sending data.
        await Future.delayed(const Duration(seconds: 1));
      }
      service.invoke('driver', {'driverId': driverId, 'available': true});
    } catch (_) {}
  }

  /// Stop sharing (call when Busy / logout).
  static Future<void> stop() async {
    try {
      final service = FlutterBackgroundService();
      if (await service.isRunning()) service.invoke('stop');
    } catch (_) {}
  }
}

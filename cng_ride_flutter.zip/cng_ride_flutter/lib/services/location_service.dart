import 'package:geolocator/geolocator.dart';

/// GPS helpers used by passenger + driver flows.
class LocationService {
  /// Ask for location permission (returns true if granted).
  static Future<bool> ensurePermission() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      return perm == LocationPermission.whileInUse ||
          perm == LocationPermission.always;
    } catch (_) {
      return false;
    }
  }

  /// Returns current position, or null when permission denied / timeout.
  static Future<Position?> currentPosition() async {
    try {
      if (!await ensurePermission()) return null;
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
    } catch (_) {
      return null;
    }
  }

  /// Continuous position updates (driver live location, passenger dot).
  /// Never emits errors: they are swallowed so a missing permission
  /// or disabled GPS can't crash the app.
  static Stream<Position> positionStream({int distanceFilterMeters = 10}) {
    return Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distanceFilterMeters,
      ),
    ).handleError((_) {});
  }

  static double distanceKm(
      double lat1, double lon1, double lat2, double lon2) {
    return Geolocator.distanceBetween(lat1, lon1, lat2, lon2) / 1000.0;
  }
}

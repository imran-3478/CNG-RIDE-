import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/location_service.dart';
import 'app_theme.dart';

/// Driver list: cards with photo placeholder, name, rating,
/// vehicle number, distance, Available/Busy badge, call button.
/// Matches the UI mockup's driver list screen.
class DriverListScreen extends StatefulWidget {
  const DriverListScreen({super.key});

  @override
  State<DriverListScreen> createState() =>
      _DriverListScreenState();
}

class _DriverListScreenState extends State<DriverListScreen> {
  bool _loading = true;
  String _filter = 'all'; // all | available | busy
  List<Map<String, dynamic>> _drivers = [];
  double? _myLat;
  double? _myLng;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final pos = await LocationService.currentPosition();
      final data = await Supabase.instance.client
          .from('drivers')
          .select(
              'id, vehicle_name, vehicle_number, available, latitude, longitude, profiles(full_name, phone, avatar_url)')
          .order('updated_at', ascending: false)
          .limit(50);
      if (!mounted) return;
      setState(() {
        _myLat = pos?.latitude;
        _myLng = pos?.longitude;
        _drivers =
            List<Map<String, dynamic>>.from(data as List);
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  double? _distanceKm(Map<String, dynamic> d) {
    if (_myLat == null || _myLng == null) return null;
    final lat = (d['latitude'] as num?)?.toDouble();
    final lng = (d['longitude'] as num?)?.toDouble();
    if (lat == null || lng == null) return null;
    return Geolocator.distanceBetween(
            _myLat!, _myLng!, lat, lng) /
        1000;
  }

  Future<void> _call(String phone) async {
    if (phone.isEmpty) return;
    final uri = Uri.parse('tel:$phone');
    try {
      await launchUrl(uri);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _drivers.where((d) {
      final av = d['available'] == true;
      if (_filter == 'available') return av;
      if (_filter == 'busy') return !av;
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('কাছের CNG ড্রাইভার')),
      body: Column(
        children: [
          // Filter pills
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _pill('সব', 'all'),
                const SizedBox(width: 8),
                _pill('Available', 'available'),
                const SizedBox(width: 8),
                _pill('Busy', 'busy'),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator())
                : filtered.isEmpty
                    ? const Center(
                        child: Text('কোনো ড্রাইভার পাওয়া যায়নি'))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          itemCount: filtered.length,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12),
                          itemBuilder: (_, i) =>
                              _card(filtered[i]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _pill(String label, String value) {
    final sel = _filter == value;
    return ChoiceChip(
      label: Text(label),
      selected: sel,
      onSelected: (_) =>
          setState(() => _filter = value),
      selectedColor: AppTheme.green800,
      labelStyle: TextStyle(
        color: sel ? Colors.white : Colors.black87,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _card(Map<String, dynamic> d) {
    final prof = d['profiles'] as Map<String, dynamic>?;
    final name = (prof?['full_name'] ??
            d['vehicle_name'] ??
            'ড্রাইভার')
        .toString();
    final phone = (prof?['phone'] ?? '').toString();
    final vehicle =
        (d['vehicle_number'] ?? '').toString();
    final available = d['available'] == true;
    final dist = _distanceKm(d);
    final avatar = (prof?['avatar_url'] ?? '').toString();

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // Photo
            CircleAvatar(
              radius: 32,
              backgroundColor: AppTheme.green50,
              backgroundImage: avatar.isNotEmpty
                  ? NetworkImage(avatar)
                  : null,
              child: avatar.isEmpty
                  ? const Icon(Icons.person,
                      size: 36, color: AppTheme.green800)
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      const Icon(Icons.star,
                          size: 14, color: Colors.amber),
                      const Text(' 4.8 (120)',
                          style: TextStyle(fontSize: 12)),
                      if (vehicle.isNotEmpty)
                        Text(' • $vehicle',
                            style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (dist != null)
                        Text(
                          '📍 ${dist.toStringAsFixed(1)} কিমি',
                          style: const TextStyle(
                              fontSize: 12,
                              color: Colors.grey),
                        ),
                      const SizedBox(width: 8),
                      Container(
                        padding:
                            const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3),
                        decoration: BoxDecoration(
                          color: available
                              ? AppTheme.green50
                              : Colors.orange.shade50,
                          borderRadius:
                              BorderRadius.circular(8),
                        ),
                        child: Text(
                          available
                              ? 'Available'
                              : 'Busy',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: available
                                ? AppTheme.green800
                                : Colors.orange.shade800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Call button
            Container(
              decoration: const BoxDecoration(
                color: AppTheme.green800,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.call,
                    color: Colors.white),
                onPressed: () => _call(phone),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

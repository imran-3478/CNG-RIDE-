import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../screens/admin_panel_screen.dart';
import '../screens/login_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/ride_history_screen.dart';
import '../screens/wallet_screen.dart';

/// Side menu: Profile, Wallet (driver), Ride History, Logout.
/// Gives the native app the same options as the web app.
class AppDrawer extends StatelessWidget {
  final bool isDriver;

  const AppDrawer({super.key, required this.isDriver});

  Future<void> _logout(BuildContext context) async {
    await Supabase.instance.client.auth.signOut();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = AppConfig.isAdminEmail(
        Supabase.instance.client.auth.currentUser?.email);
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.teal),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(Icons.directions_car,
                    size: 44, color: Colors.white),
                SizedBox(height: 8),
                Text('CNG Ride',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          ListTile(
            leading:
                const Icon(Icons.person, color: Colors.teal),
            title: const Text('প্রোফাইল'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const ProfileScreen()),
              );
            },
          ),
          if (isDriver)
            ListTile(
              leading: const Icon(Icons.account_balance_wallet,
                  color: Colors.teal),
              title: const Text('ওয়ালেট ও রিচার্জ'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const WalletScreen()),
                );
              },
            ),
          ListTile(
            leading:
                const Icon(Icons.history, color: Colors.teal),
            title: const Text('রাইড হিস্ট্রি'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        const RideHistoryScreen()),
              );
            },
          ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings,
                  color: Colors.purple),
              title: const Text('👑 Admin Panel',
                  style: TextStyle(
                      color: Colors.purple,
                      fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          const AdminPanelScreen()),
                );
              },
            ),
          const Divider(),
          ListTile(
            leading:
                const Icon(Icons.logout, color: Colors.red),
            title: const Text('লগআউট',
                style: TextStyle(color: Colors.red)),
            onTap: () => _logout(context),
          ),
        ],
      ),
    );
  }
}

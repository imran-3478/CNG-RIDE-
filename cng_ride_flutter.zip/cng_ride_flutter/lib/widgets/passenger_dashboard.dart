import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../screens/passenger_home.dart';
import '../screens/ride_history_screen.dart';
import '../screens/support_screens.dart';
import '../widgets/app_drawer.dart';
import '../widgets/app_theme.dart';
import 'driver_list_screen.dart';

/// Passenger dashboard: hero card + quick actions grid.
/// Matches the UI mockup's home screen.
class PassengerDashboard extends StatefulWidget {
  const PassengerDashboard({super.key});

  @override
  State<PassengerDashboard> createState() =>
      _PassengerDashboardState();
}

class _PassengerDashboardState
    extends State<PassengerDashboard> {
  String _name = '';
  int _availableCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final uid =
          Supabase.instance.client.auth.currentUser?.id;
      if (uid != null) {
        final prof = await Supabase.instance.client
            .from('profiles')
            .select('full_name')
            .eq('id', uid)
            .maybeSingle();
        if (mounted) {
          setState(() => _name =
              (prof?['full_name'] ?? '').toString());
        }
      }
      final drivers = await Supabase.instance.client
          .from('drivers')
          .select('id')
          .eq('available', true);
      if (mounted) {
        setState(
            () => _availableCount = (drivers as List).length);
      }
    } catch (_) {}
  }

  void _go(Widget page) {
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(isDriver: false),
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('বর্তমান অবস্থান',
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.normal)),
            Text(
              _name.isEmpty ? 'টাঙ্গাইল, বাংলাদেশ' : '$_name',
              style: const TextStyle(fontSize: 15),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero card
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: AppTheme.gradient,
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.green800.withOpacity(0.3),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            'নিরাপদ ও দ্রুত',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'CNG যাত্রা',
                            style: TextStyle(
                              color: AppTheme.amber,
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 6),
                          Text(
                            'আপনার পাশে সবসময়',
                            style: TextStyle(
                                color: Colors.white70,
                                fontSize: 13),
                          ),
                          SizedBox(height: 4),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '$_availableCountটি CNG available',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Quick actions grid
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics:
                      const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.05,
                  children: [
                    _action(
                      Icons.local_taxi,
                      'কাছের CNG',
                      () => _go(const PassengerHome()),
                    ),
                    _action(
                      Icons.directions_car,
                      'আমার রাইড',
                      () => _go(const RideHistoryScreen()),
                    ),
                    _action(
                      Icons.person,
                      'প্রোফাইল',
                      () {},
                    ),
                    _action(
                      Icons.history,
                      'ইতিহাস',
                      () => _go(const RideHistoryScreen()),
                    ),
                    _action(
                      Icons.support_agent,
                      'সাপোর্ট',
                      () => _go(const SupportScreen()),
                    ),
                    _action(
                      Icons.settings,
                      'সেটিংস',
                      () => _go(const SettingsScreen()),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              // Find CNG button
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16),
                child: ElevatedButton.icon(
                  onPressed: () =>
                      _go(const DriverListScreen()),
                  icon: const Icon(Icons.list),
                  label: const Text('ড্রাইভার তালিকা দেখো'),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _action(
      IconData icon, String label, VoidCallback onTap) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.green50,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon,
                  size: 28, color: AppTheme.green800),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

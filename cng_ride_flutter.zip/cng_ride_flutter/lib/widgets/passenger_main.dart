import 'package:flutter/material.dart';

import '../screens/passenger_home.dart';
import '../screens/profile_screen.dart';
import '../screens/ride_history_screen.dart';
import 'passenger_dashboard.dart';

/// Passenger main: bottom navigation (Home, Find CNG, My Rides, Profile).
/// Matches the UI mockup's bottom bar.
class PassengerMain extends StatefulWidget {
  const PassengerMain({super.key});

  @override
  State<PassengerMain> createState() => _PassengerMainState();
}

class _PassengerMainState extends State<PassengerMain> {
  int _index = 0;

  static const _tabs = [
    PassengerDashboard(),
    PassengerHome(),
    RideHistoryScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _tabs),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'হোম',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'CNG খুঁজুন',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_car),
            label: 'আমার রাইড',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'প্রোফাইল',
          ),
        ],
      ),
    );
  }
}

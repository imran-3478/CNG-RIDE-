import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';

/// Free map tile URLs.
class MapTiles {
  static const street =
      'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  // Esri World Imagery (free satellite tiles).
  static const satellite =
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
}

/// Toggle button to switch between street and satellite view.
/// Place inside a Stack over the map.
class SatelliteToggle extends StatelessWidget {
  final bool isSatellite;
  final VoidCallback onToggle;

  const SatelliteToggle({
    super.key,
    required this.isSatellite,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 76,
      right: 12,
      child: Material(
        elevation: 4,
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: onToggle,
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: isSatellite
                  ? Colors.teal.shade700
                  : Colors.white,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.satellite_alt,
                  size: 18,
                  color: isSatellite
                      ? Colors.white
                      : Colors.teal.shade700,
                ),
                const SizedBox(width: 4),
                Text(
                  isSatellite ? 'Street' : 'Satellite',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: isSatellite
                        ? Colors.white
                        : Colors.teal.shade700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Builds the TileLayer for the current view mode.
TileLayer buildTileLayer(bool isSatellite) {
  return TileLayer(
    urlTemplate:
        isSatellite ? MapTiles.satellite : MapTiles.street,
    userAgentPackageName: 'com.cngride.cng_ride_app',
  );
}
